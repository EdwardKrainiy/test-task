package com.springtestapp.controller;

import com.springtestapp.model.FlagObject;
import com.springtestapp.util.literal.LabelText;
import com.springtestapp.util.literal.UiLanguageType;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@Log4j2
@RequiredArgsConstructor
public class MainController {

  @GetMapping("/home")
  String home(@RequestParam(value = "lang", defaultValue = "eng") String lang, Model model) {
    initializeModelAttributes(lang, model);
    return "main";
  }

  private void initializeModelAttributes(String lang, Model model){
    if(lang.equals(UiLanguageType.RU_LANG)){
      model.addAttribute("labelText", LabelText.RU_TEXT);
    } else if(lang.equals(UiLanguageType.ENG_LANG)){
      model.addAttribute("labelText", LabelText.EN_TEXT);
    }
    model.addAttribute("languages", Arrays.asList(UiLanguageType.ENG_LANG, UiLanguageType.RU_LANG));
    model.addAttribute("selectedLang", lang);
    model.addAttribute("flag", new FlagObject());
  }
}
