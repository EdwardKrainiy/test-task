package com.springtestapp.util.literal;

public class UiLanguageType {
  public static final String RU_LANG = "ru";
  public static final String ENG_LANG = "eng";
}
