package com.springtestapp.model;

public class FlagObject {
  private static boolean flag = true;

  public boolean isFlag() {
    return flag;
  }

  public boolean setVisible(){
    flag = !flag;
    return flag;
  }
}
