package com.example.util.literal;

public class UiLanguageType {
  public static final String RU_LANG = "RU";
  public static final String ENG_LANG = "ENG";
}
