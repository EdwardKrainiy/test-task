package com.example.util.literal;

public class LabelText {
  public static final String RU_TEXT = "Привет, мир!";
  public static final String EN_TEXT = "Hello, world!";
}
