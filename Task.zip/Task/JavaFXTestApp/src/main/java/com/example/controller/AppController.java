package com.example.controller;

import com.example.model.ClassWithCounterExample;
import com.example.util.literal.InfoText;
import com.example.util.literal.LabelText;
import com.example.util.literal.UiLanguageType;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

public class AppController implements Initializable {
  private String selectedLang = UiLanguageType.RU_LANG;

  public void setSelectedLang(String selectedLang) {
    this.selectedLang = selectedLang;
  }

  @FXML
  private Label labelText;

  @FXML
  private ComboBox<String> comboBox;

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle){
    ObservableList<String> languages = FXCollections.observableList(new ArrayList<>());
    languages.addListener(
        (ListChangeListener<String>)
            change -> {
              change.next();
              if(change.wasAdded() || change.wasRemoved()){
                System.out.println(InfoText.LIST_SIZE_CHANGED_CREATED_TEXT);
              }
            });
    languages.add(UiLanguageType.RU_LANG);
    languages.add(UiLanguageType.ENG_LANG);
    comboBox.setItems(FXCollections.observableArrayList(languages));
  }

  @FXML
  void onSetLabelClick() {
    if(labelText.getText().isEmpty()){
      if(selectedLang.equals(UiLanguageType.RU_LANG)){
        labelText.setText(LabelText.RU_TEXT);
      } else {
        labelText.setText(LabelText.EN_TEXT);
      }
    } else {
      labelText.setText("");
    }
  }

  @FXML
  void selectLang() {
    setSelectedLang(comboBox.getSelectionModel().getSelectedItem());
  }

  @FXML
  void onAddObjectClick() {
    ClassWithCounterExample createdObject = new ClassWithCounterExample();
    labelText.setText(String.format("%d", ClassWithCounterExample.getCounter()));
  }
}
