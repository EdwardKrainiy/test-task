package com.example.util.literal;

public class InfoText {
  public static final String OBJECT_CREATED_TEXT = "One more object was added. Amount of objects: %d%n";
  public static final String LIST_SIZE_CHANGED_CREATED_TEXT = "List size changed.";
}
