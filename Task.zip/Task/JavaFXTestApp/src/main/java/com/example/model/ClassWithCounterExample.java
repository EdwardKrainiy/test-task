package com.example.model;

import com.example.util.literal.InfoText;

public class ClassWithCounterExample {

  private static int counter = 0;
  {
    counter++;
    System.out.printf(InfoText.OBJECT_CREATED_TEXT, counter);
  }

  public static int getCounter() {
    return counter;
  }
}
